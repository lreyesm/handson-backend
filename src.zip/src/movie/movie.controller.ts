import { Controller } from '@nestjs/common';

@Controller('movie')
export class MovieController {}
